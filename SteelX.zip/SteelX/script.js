// Add interactivity to your site
document.querySelectorAll('.btn').forEach(button => {
  button.addEventListener('click', () => {
    alert("Redirecting to product page...");
  });
});
